/**
 * Tests for the checkout-session methods. `createCheckoutSession` carries the
 * real branching logic — embedded vs redirect ui_mode, the
 * subscription/payment/setup mode-specific blocks, metadata + orgId assembly,
 * the accountId-vs-customerEmail precedence, default quantity, sessionOverrides
 * spreading, and the component upsert with its null-coalescing defaults — so it
 * gets the most attention. The remaining functions are thin component/Stripe
 * wrappers verified for param shape and pass-through.
 */
import { describe, expect, it, vi } from "vitest";

import type { Component, RunCtx } from "../helpers.js";
import {
  createCheckoutSession,
  getCheckoutSession,
  getCheckoutSessionByStripeId,
  listCheckoutSessionsByUser,
  updateCheckoutSession,
  upsertCheckoutSession,
} from "./checkout.js";

const TO_REF = Symbol.for("toReferencePath");

/** Component proxy exposing the billing refs these functions resolve. */
function makeComponent(): Component {
  const ref = (path: string) => ({ [TO_REF]: `betterStripe/${path}` });
  return {
    billing: {
      queries: {
        getCheckoutSession: ref("billing/queries/getCheckoutSession"),
        getCheckoutSessionByStripeId: ref(
          "billing/queries/getCheckoutSessionByStripeId",
        ),
        listCheckoutSessionsByUser: ref(
          "billing/queries/listCheckoutSessionsByUser",
        ),
      },
      mutations: {
        upsertCheckoutSession: ref("billing/mutations/upsertCheckoutSession"),
      },
    },
    products: {
      queries: {
        getPriceByStripeId: ref("products/queries/getPriceByStripeId"),
        getProductByStripeId: ref("products/queries/getProductByStripeId"),
      },
    },
    core: {
      queries: {
        getAccountByStripeId: ref("core/queries/getAccountByStripeId"),
      },
    },
  } as unknown as Component;
}

/** Build a ctx whose runQuery routes by component ref path (for price validation). */
function routedCtx(routes: Record<string, unknown>) {
  const runQuery = vi.fn(async (refObj: Record<symbol, string>) => {
    const path = refObj[TO_REF].replace(/^betterStripe\//, "");
    return routes[path] ?? null;
  });
  return {
    runQuery,
    runMutation: vi.fn().mockResolvedValue(undefined),
  } as unknown as RunCtx & {
    runQuery: ReturnType<typeof vi.fn>;
    runMutation: ReturnType<typeof vi.fn>;
  };
}

function makeCtx(queryResult?: unknown) {
  return {
    runQuery: vi.fn().mockResolvedValue(queryResult),
    runMutation: vi.fn().mockResolvedValue(undefined),
  } as unknown as RunCtx & {
    runQuery: ReturnType<typeof vi.fn>;
    runMutation: ReturnType<typeof vi.fn>;
  };
}

function makeStripe() {
  return {
    prices: {
      retrieve: vi.fn().mockRejectedValue({ code: "resource_missing" }),
    },
    checkout: {
      sessions: {
        create: vi.fn(),
        update: vi.fn(),
      },
    },
  };
}

const asStripe = (s: ReturnType<typeof makeStripe>) =>
  s as unknown as Parameters<typeof createCheckoutSession>[0];

/** Default Stripe session response used when a test does not care about it. */
function sessionResponse(overrides: Record<string, unknown> = {}) {
  return {
    id: "cs_test_1",
    status: "open",
    client_secret: "cs_secret_1",
    url: null,
    ...overrides,
  };
}

describe("createCheckoutSession", () => {
  it("builds a subscription embedded session and upserts the resulting row", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({ id: "cs_sub", client_secret: "secret_sub", url: null }),
    );
    const ctx = makeCtx();

    const result = await createCheckoutSession(
      asStripe(stripe),
      makeComponent(),
      ctx,
      {
        userId: "user_1",
        orgId: "org_1",
        stripePriceId: "price_1",
        mode: "subscription",
        returnUrl: "https://app.test/return",
      },
    );

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    // metadata includes userId + orgId; line_items default quantity 1
    expect(createArg.metadata).toEqual({ userId: "user_1", orgId: "org_1" });
    expect(createArg.line_items).toEqual([{ price: "price_1", quantity: 1 }]);
    expect(createArg.mode).toBe("subscription");
    // subscription mode → subscription_data carries the same metadata
    expect(createArg.subscription_data).toEqual({
      metadata: { userId: "user_1", orgId: "org_1" },
    });
    expect(createArg.subscription_data.trial_period_days).toBeUndefined();
    // no payment_intent_data for subscription mode
    expect(createArg.payment_intent_data).toBeUndefined();
    // embedded ui_mode is the default
    expect(createArg.ui_mode).toBe("embedded_page");
    expect(createArg.return_url).toBe("https://app.test/return");
    expect(createArg.success_url).toBeUndefined();
    expect(createArg.cancel_url).toBeUndefined();

    // upsert mutation carries derived row
    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs).toMatchObject({
      stripeSessionId: "cs_sub",
      userId: "user_1",
      orgId: "org_1",
      mode: "subscription",
      status: "open",
      clientSecret: "secret_sub",
      metadata: { userId: "user_1", orgId: "org_1" },
    });
    expect(upsertArgs.url).toBeUndefined();

    expect(result).toEqual({
      stripeSessionId: "cs_sub",
      clientSecret: "secret_sub",
      url: undefined,
    });
  });

  it("adds trial_period_days to subscription_data when trialDays is set", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      trialDays: 14,
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data.trial_period_days).toBe(14);
  });

  it("omits orgId from metadata when not provided", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_solo",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.metadata).toEqual({ userId: "user_solo" });
    expect(createArg.metadata.orgId).toBeUndefined();
    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.orgId).toBeUndefined();
  });

  it("merges caller metadata with the userId/orgId identifiers", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      orgId: "org_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      metadata: { plan: "pro", source: "pricing-page" },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.metadata).toEqual({
      plan: "pro",
      source: "pricing-page",
      userId: "user_1",
      orgId: "org_1",
    });
  });

  it("uses payment_intent_data and redirect urls for a payment redirect session", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({ id: "cs_pay" }),
    );
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "payment",
      uiMode: "redirect",
      returnUrl: "https://app.test/done",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    // payment mode → payment_intent_data; no subscription_data
    expect(createArg.payment_intent_data).toEqual({
      metadata: { userId: "user_1" },
    });
    expect(createArg.subscription_data).toBeUndefined();
    // redirect ui_mode → success/cancel urls, no embedded fields
    expect(createArg.ui_mode).toBeUndefined();
    expect(createArg.return_url).toBeUndefined();
    expect(createArg.success_url).toBe(
      "https://app.test/done?session_id={CHECKOUT_SESSION_ID}",
    );
    expect(createArg.cancel_url).toBe("https://app.test/done");
  });

  it("emits neither subscription_data nor payment_intent_data for setup mode", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "setup",
      returnUrl: "https://app.test/return",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data).toBeUndefined();
    expect(createArg.payment_intent_data).toBeUndefined();
    expect(createArg.mode).toBe("setup");
  });

  it("forwards an explicit quantity to line_items", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_seat",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      quantity: 5,
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.line_items).toEqual([
      { price: "price_seat", quantity: 5 },
    ]);
  });

  it("sets customer_account when accountId is provided", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      accountId: "acct_123",
      customerEmail: "ignored@test.com",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    // accountId takes precedence over customerEmail
    expect(createArg.customer_account).toBe("acct_123");
    expect(createArg.customer_email).toBeUndefined();
    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.accountId).toBe("acct_123");
  });

  it("falls back to customer_email when no accountId is given", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      customerEmail: "buyer@test.com",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.customer_email).toBe("buyer@test.com");
    expect(createArg.customer_account).toBeUndefined();
  });

  it("sets neither customer field when both accountId and email are absent", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.customer_account).toBeUndefined();
    expect(createArg.customer_email).toBeUndefined();
  });

  it("spreads sessionOverrides over the computed params", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      sessionOverrides: {
        allow_promotion_codes: true,
        mode: "payment", // override wins over computed mode
      },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.allow_promotion_codes).toBe(true);
    expect(createArg.mode).toBe("payment");
  });

  it("defaults status to 'open' and url/clientSecret to undefined when Stripe returns nullish values", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue({
      id: "cs_minimal",
      status: null,
      client_secret: null,
      url: null,
    });
    const ctx = makeCtx();

    const result = await createCheckoutSession(
      asStripe(stripe),
      makeComponent(),
      ctx,
      {
        userId: "user_1",
        stripePriceId: "price_1",
        mode: "subscription",
        returnUrl: "https://app.test/return",
      },
    );

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.status).toBe("open");
    expect(upsertArgs.clientSecret).toBeUndefined();
    expect(upsertArgs.url).toBeUndefined();
    expect(result).toEqual({
      stripeSessionId: "cs_minimal",
      clientSecret: undefined,
      url: undefined,
    });
  });

  it("propagates the redirect url returned by Stripe into the upsert and result", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({
        id: "cs_redir",
        status: "complete",
        client_secret: null,
        url: "https://checkout.stripe.com/c/pay/cs_redir",
      }),
    );
    const ctx = makeCtx();

    const result = await createCheckoutSession(
      asStripe(stripe),
      makeComponent(),
      ctx,
      {
        userId: "user_1",
        stripePriceId: "price_1",
        mode: "payment",
        uiMode: "redirect",
        returnUrl: "https://app.test/done",
      },
    );

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.status).toBe("complete");
    expect(upsertArgs.url).toBe("https://checkout.stripe.com/c/pay/cs_redir");
    expect(result.url).toBe("https://checkout.stripe.com/c/pay/cs_redir");
    expect(result.clientSecret).toBeUndefined();
  });

  it("persists the price id on the upserted checkout-session row", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({ id: "cs_priced" }),
    );
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_pro_monthly",
      mode: "subscription",
      returnUrl: "https://app.test/return",
    });

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.priceId).toBe("price_pro_monthly");
  });

  it("targets the upsertCheckoutSession component ref", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
    });

    const [ref] = ctx.runMutation.mock.calls[0];
    expect(ref).toEqual({
      [TO_REF]: "betterStripe/billing/mutations/upsertCheckoutSession",
    });
  });

  it("throws when ctx has no runMutation (runMutationOrThrow guard)", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = { runQuery: vi.fn() } as unknown as RunCtx;

    await expect(
      createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
        userId: "user_1",
        stripePriceId: "price_1",
        mode: "subscription",
        returnUrl: "https://app.test/return",
      }),
    ).rejects.toThrow(/requires a Convex ctx with runMutation/);
  });
});

describe("createCheckoutSession — destination + fee (BTS-15, subscription)", () => {
  it("routes a percent-only fee via transfer_data + application_fee_percent", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({ id: "cs_dest" }),
    );
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      destinationAccountId: "acct_store",
      feeConfig: { percent: 10 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data.transfer_data).toEqual({
      destination: "acct_store",
    });
    expect(createArg.subscription_data.application_fee_percent).toBe(10);
    expect(createArg.subscription_data.metadata.bsFeeMode).toBeUndefined();
    expect(createArg.payment_method_types).toBeUndefined();

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs).toMatchObject({
      chargeType: "destination",
      destinationAccountId: "acct_store",
      applicationFeePercent: 10,
    });
  });

  it("flags percent+fixed fees for per-invoice computation (no application_fee_percent)", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({ id: "cs_dest2" }),
    );
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      destinationAccountId: "acct_store",
      feeConfig: { percent: 2.9, fixed: 30 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data.transfer_data).toEqual({
      destination: "acct_store",
    });
    expect(createArg.subscription_data.application_fee_percent).toBeUndefined();
    expect(createArg.subscription_data.metadata.bsFeeMode).toBe("per_invoice");

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.chargeType).toBe("destination");
    expect(upsertArgs.destinationAccountId).toBe("acct_store");
  });

  it("adds no transfer_data or fees without a destinationAccountId", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      feeConfig: { percent: 10 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data.transfer_data).toBeUndefined();
    expect(createArg.subscription_data.application_fee_percent).toBeUndefined();
    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.chargeType).toBeUndefined();
  });

  it("derives the persisted fee row from the FINAL request when sessionOverrides replace subscription_data", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      destinationAccountId: "acct_store",
      feeConfig: { percent: 10 },
      // Override wholesale-replaces subscription_data, dropping transfer_data/fee.
      sessionOverrides: { subscription_data: { metadata: {} } },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data.transfer_data).toBeUndefined();
    // Persisted row must reflect the actual request — no stale fee/routing.
    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.chargeType).toBeUndefined();
    expect(upsertArgs.destinationAccountId).toBeUndefined();
    expect(upsertArgs.applicationFeePercent).toBeUndefined();
  });
});

describe("createCheckoutSession — destination + fee (BTS-16, one-time payment)", () => {
  it("computes application_fee_amount when the amount is known", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({ id: "cs_pay_fee" }),
    );
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      destinationAccountId: "acct_store",
      feeConfig: { percent: 10, fixed: 30 },
      amount: 10000, // round(10000*0.10) + 30 = 1030
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.payment_intent_data.transfer_data).toEqual({
      destination: "acct_store",
    });
    expect(createArg.payment_intent_data.application_fee_amount).toBe(1030);
    expect(createArg.payment_intent_data.metadata.bsFeeMode).toBeUndefined();

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs).toMatchObject({
      chargeType: "destination",
      destinationAccountId: "acct_store",
      applicationFeeAmount: 1030,
    });
  });

  it("defers to the webhook when the amount is unknown", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(
      sessionResponse({ id: "cs_pay_defer" }),
    );
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      destinationAccountId: "acct_store",
      feeConfig: { percent: 10 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.payment_intent_data.transfer_data).toEqual({
      destination: "acct_store",
    });
    expect(
      createArg.payment_intent_data.application_fee_amount,
    ).toBeUndefined();
    expect(createArg.payment_intent_data.metadata.bsFeeMode).toBe("per_charge");
  });

  it("adds no transfer_data or fees without a destinationAccountId", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      feeConfig: { percent: 10 },
      amount: 10000,
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.payment_intent_data).toEqual({
      metadata: { userId: "user_1" },
    });
  });
});

describe("createCheckoutSession — N-recipient split (BTS-21)", () => {
  it("routes a >1 split (payment mode) via separate charges (no transfer_data/application_fee)", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();
    const split = [
      {
        destinationAccountId: "acct_store",
        role: "store" as const,
        percent: 80,
      },
      {
        destinationAccountId: "acct_aff",
        role: "affiliate" as const,
        percent: 5,
      },
    ];

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      split,
      feeConfig: { percent: 10 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.payment_intent_data.transfer_data).toBeUndefined();
    expect(createArg.payment_intent_data.metadata.bsChargeType).toBe(
      "separate",
    );
    expect(
      JSON.parse(createArg.payment_intent_data.metadata.bsSplit),
    ).toHaveLength(2);

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.chargeType).toBe("separate");
    expect(upsertArgs.splitRecipients).toHaveLength(2);
  });

  it("routes a >1 split on a subscription via separate charges (markers on subscription_data)", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      split: [
        { destinationAccountId: "acct_store", role: "store", percent: 80 },
        { destinationAccountId: "acct_aff", role: "affiliate", percent: 5 },
      ],
      feeConfig: { percent: 10 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data.transfer_data).toBeUndefined();
    expect(createArg.subscription_data.application_fee_percent).toBeUndefined();
    expect(createArg.subscription_data.metadata.bsChargeType).toBe("separate");
    expect(
      JSON.parse(createArg.subscription_data.metadata.bsSplit),
    ).toHaveLength(2);

    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.chargeType).toBe("separate");
    expect(upsertArgs.splitRecipients).toHaveLength(2);
  });

  it("treats a single-recipient split as a destination charge", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      split: [
        { destinationAccountId: "acct_store", role: "store", percent: 90 },
      ],
      feeConfig: { percent: 10 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.subscription_data.transfer_data).toEqual({
      destination: "acct_store",
    });
    expect(createArg.subscription_data.application_fee_percent).toBe(10);
    const [, upsertArgs] = ctx.runMutation.mock.calls[0];
    expect(upsertArgs.chargeType).toBe("destination");
  });

  it("routes a >1 split in payment mode via separate charges", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      split: [
        { destinationAccountId: "acct_store", role: "store", amount: 8000 },
        { destinationAccountId: "acct_aff", role: "affiliate", amount: 1000 },
      ],
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.payment_intent_data.transfer_data).toBeUndefined();
    expect(createArg.payment_intent_data.metadata.bsChargeType).toBe(
      "separate",
    );
  });

  it("rejects split/destination/fee in setup mode", async () => {
    const stripe = makeStripe();
    const ctx = makeCtx();

    await expect(
      createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
        userId: "buyer_1",
        stripePriceId: "price_1",
        mode: "setup",
        returnUrl: "https://app.test/return",
        accountId: "acct_buyer",
        split: [
          { destinationAccountId: "acct_store", role: "store", amount: 100 },
        ],
      }),
    ).rejects.toThrow(/setup/i);
    expect(stripe.checkout.sessions.create).not.toHaveBeenCalled();
  });

  it("strips reserved bs* keys from caller metadata so they can't forge split instructions", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      // A non-split caller trying to forge webhook instructions.
      metadata: {
        bsChargeType: "separate",
        bsSplit:
          '[{"destinationAccountId":"acct_evil","role":"store","amount":9999}]',
        plan: "pro",
      },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.metadata.bsChargeType).toBeUndefined();
    expect(createArg.metadata.bsSplit).toBeUndefined();
    expect(createArg.metadata.plan).toBe("pro"); // legit keys kept
    expect(createArg.payment_intent_data.metadata.bsChargeType).toBeUndefined();
  });

  it("rejects a split whose percents exceed 100", async () => {
    const stripe = makeStripe();
    const ctx = makeCtx();

    await expect(
      createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
        userId: "buyer_1",
        stripePriceId: "price_1",
        mode: "subscription",
        returnUrl: "https://app.test/return",
        accountId: "acct_buyer",
        split: [
          { destinationAccountId: "acct_store", role: "store", percent: 70 },
          { destinationAccountId: "acct_aff", role: "affiliate", percent: 40 },
        ],
      }),
    ).rejects.toThrow();
    expect(stripe.checkout.sessions.create).not.toHaveBeenCalled();
  });
});

describe("createCheckoutSession — price-on-platform validation (BTS-15)", () => {
  it("rejects a destination charge whose price belongs to a connected account", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "products/queries/getPriceByStripeId": {
        stripePriceId: "price_1",
        stripeProductId: "prod_1",
      },
      "products/queries/getProductByStripeId": {
        stripeProductId: "prod_1",
        accountId: "acct_seller", // connected-account-owned → invalid
      },
    });

    await expect(
      createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
        userId: "buyer_1",
        stripePriceId: "price_1",
        mode: "subscription",
        returnUrl: "https://app.test/return",
        accountId: "acct_buyer",
        destinationAccountId: "acct_store",
        feeConfig: { percent: 10 },
      }),
    ).rejects.toThrow(/platform/i);
    expect(stripe.checkout.sessions.create).not.toHaveBeenCalled();
    // The catalog lookups use the right ids (price → its product).
    // The catalog lookups use the right ids (price → its product). Positions
    // are not asserted: the BTS-32 statement-descriptor account lookup also
    // runs during session creation.
    expect(ctx.runQuery).toHaveBeenCalledWith(expect.any(Object), {
      stripePriceId: "price_1",
    });
    expect(ctx.runQuery).toHaveBeenCalledWith(expect.any(Object), {
      stripeProductId: "prod_1",
    });
  });

  it("allows a platform price tagged to a store in the component catalog", async () => {
    const stripe = makeStripe();
    stripe.prices.retrieve.mockResolvedValue({ id: "price_1" });
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "products/queries/getPriceByStripeId": { stripeProductId: "prod_1" },
      "products/queries/getProductByStripeId": { accountId: "acct_store" },
    });
    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      destinationAccountId: "acct_store",
    });
    expect(stripe.prices.retrieve).toHaveBeenCalledWith("price_1");
    expect(stripe.checkout.sessions.create).toHaveBeenCalled();
  });

  it("allows a destination charge for a platform-owned price", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "products/queries/getPriceByStripeId": {
        stripePriceId: "price_1",
        stripeProductId: "prod_1",
      },
      "products/queries/getProductByStripeId": {
        stripeProductId: "prod_1",
        // no accountId → platform-owned
      },
    });

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      accountId: "acct_buyer",
      destinationAccountId: "acct_store",
      feeConfig: { percent: 10 },
    });
    // The catalog lookups use the right ids (price → its product). Positions
    // are not asserted: the BTS-32 statement-descriptor account lookup also
    // runs during session creation.
    expect(ctx.runQuery).toHaveBeenCalledWith(expect.any(Object), {
      stripePriceId: "price_1",
    });
    expect(ctx.runQuery).toHaveBeenCalledWith(expect.any(Object), {
      stripeProductId: "prod_1",
    });
    expect(stripe.checkout.sessions.create).toHaveBeenCalled();
  });

  it("validates the FINAL request — sessionOverrides can't inject a destination to bypass the check", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "products/queries/getPriceByStripeId": {
        stripePriceId: "price_1",
        stripeProductId: "prod_1",
      },
      "products/queries/getProductByStripeId": {
        stripeProductId: "prod_1",
        accountId: "acct_seller", // connected-account-owned → invalid
      },
    });

    await expect(
      createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
        userId: "buyer_1",
        stripePriceId: "price_1",
        mode: "subscription",
        returnUrl: "https://app.test/return",
        accountId: "acct_buyer",
        // No destinationAccountId on opts — but overrides inject one.
        sessionOverrides: {
          subscription_data: { transfer_data: { destination: "acct_store" } },
        },
      }),
    ).rejects.toThrow(/platform/i);
    expect(stripe.checkout.sessions.create).not.toHaveBeenCalled();
  });

  it("skips validation when there is no destination (plain checkout)", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = makeCtx();

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
    });
    // No price lookup performed for a non-destination checkout.
    expect(ctx.runQuery).not.toHaveBeenCalled();
    expect(stripe.checkout.sessions.create).toHaveBeenCalled();
  });
});

describe("getCheckoutSession", () => {
  it("queries by internal session id and returns the row", async () => {
    const ctx = makeCtx({ stripeSessionId: "cs_1" });
    const result = await getCheckoutSession(makeComponent(), ctx, {
      sessionId: "internal_1",
    });

    expect(result).toEqual({ stripeSessionId: "cs_1" });
    const [ref, args] = ctx.runQuery.mock.calls[0];
    expect(ref).toEqual({
      [TO_REF]: "betterStripe/billing/queries/getCheckoutSession",
    });
    expect(args).toEqual({ sessionId: "internal_1" });
  });

  it("returns null when the session does not exist", async () => {
    const ctx = makeCtx(null);
    const result = await getCheckoutSession(makeComponent(), ctx, {
      sessionId: "missing",
    });
    expect(result).toBeNull();
  });
});

describe("getCheckoutSessionByStripeId", () => {
  it("queries by stripe session id and returns the row", async () => {
    const ctx = makeCtx({ stripeSessionId: "cs_abc" });
    const result = await getCheckoutSessionByStripeId(makeComponent(), ctx, {
      stripeSessionId: "cs_abc",
    });

    expect(result).toEqual({ stripeSessionId: "cs_abc" });
    const [ref, args] = ctx.runQuery.mock.calls[0];
    expect(ref).toEqual({
      [TO_REF]: "betterStripe/billing/queries/getCheckoutSessionByStripeId",
    });
    expect(args).toEqual({ stripeSessionId: "cs_abc" });
  });
});

describe("listCheckoutSessionsByUser", () => {
  it("forwards userId and optional status filter and returns the rows", async () => {
    const ctx = makeCtx([
      { stripeSessionId: "cs_a" },
      { stripeSessionId: "cs_b" },
    ]);
    const result = await listCheckoutSessionsByUser(makeComponent(), ctx, {
      userId: "user_1",
      status: "complete",
    });

    expect(result).toHaveLength(2);
    const [ref, args] = ctx.runQuery.mock.calls[0];
    expect(ref).toEqual({
      [TO_REF]: "betterStripe/billing/queries/listCheckoutSessionsByUser",
    });
    expect(args).toEqual({ userId: "user_1", status: "complete" });
  });
});

describe("upsertCheckoutSession", () => {
  it("runs the upsert mutation with the given opts and returns null", async () => {
    const ctx = makeCtx();
    const result = await upsertCheckoutSession(makeComponent(), ctx, {
      stripeSessionId: "cs_up",
      userId: "user_1",
      mode: "payment",
      status: "complete",
    });

    expect(result).toBeNull();
    const [ref, args] = ctx.runMutation.mock.calls[0];
    expect(ref).toEqual({
      [TO_REF]: "betterStripe/billing/mutations/upsertCheckoutSession",
    });
    expect(args).toEqual({
      stripeSessionId: "cs_up",
      userId: "user_1",
      mode: "payment",
      status: "complete",
    });
  });

  it("throws when ctx has no runMutation", async () => {
    const ctx = { runQuery: vi.fn() } as unknown as RunCtx;
    await expect(
      upsertCheckoutSession(makeComponent(), ctx, {
        stripeSessionId: "cs_up",
        userId: "user_1",
        mode: "payment",
        status: "complete",
      }),
    ).rejects.toThrow(/requires a Convex ctx with runMutation/);
  });
});

describe("updateCheckoutSession", () => {
  it("updates the Stripe session metadata and returns the session", async () => {
    const stripe = makeStripe();
    const updated = { id: "cs_u", metadata: { plan: "pro" } };
    stripe.checkout.sessions.update.mockResolvedValue(updated);
    const ctx = makeCtx();

    const result = await updateCheckoutSession(asStripe(stripe), ctx, {
      stripeSessionId: "cs_u",
      metadata: { plan: "pro" },
    });

    expect(stripe.checkout.sessions.update).toHaveBeenCalledWith("cs_u", {
      metadata: { plan: "pro" },
    });
    expect(result).toBe(updated);
  });

  it("passes undefined metadata through when none is provided", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.update.mockResolvedValue({ id: "cs_u2" });
    const ctx = makeCtx();

    await updateCheckoutSession(asStripe(stripe), ctx, {
      stripeSessionId: "cs_u2",
    });

    expect(stripe.checkout.sessions.update).toHaveBeenCalledWith("cs_u2", {
      metadata: undefined,
    });
  });
});

describe("createCheckoutSession — per-store statement descriptor (BTS-32)", () => {
  const storeAccount = (statementDescriptor?: string) => ({
    _id: "doc_acct",
    stripeAccountId: "acct_store",
    userId: "seller_1",
    ...(statementDescriptor ? { statementDescriptor } : {}),
  });

  it("payment mode: sets statement_descriptor_suffix from the store's account record", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "core/queries/getAccountByStripeId": storeAccount("MAYAS FITNESS"),
    });

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      destinationAccountId: "acct_store",
      defaultStatementDescriptorSuffix: "PLATFORM DEF",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.payment_intent_data.statement_descriptor_suffix).toBe(
      "MAYAS FITNESS",
    );
  });

  it("payment mode: falls back to the configured default when the store has no suffix", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "core/queries/getAccountByStripeId": storeAccount(undefined),
    });

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      destinationAccountId: "acct_store",
      defaultStatementDescriptorSuffix: "PLATFORM DEF",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(createArg.payment_intent_data.statement_descriptor_suffix).toBe(
      "PLATFORM DEF",
    );
  });

  it("payment mode: omits the suffix when neither store nor default has one", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "core/queries/getAccountByStripeId": storeAccount(undefined),
    });

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      destinationAccountId: "acct_store",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect("statement_descriptor_suffix" in createArg.payment_intent_data).toBe(
      false,
    );
  });

  it("subscription mode: stashes bsStatementDescriptor for the invoice.created processor without clobbering fee markers", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({
      "core/queries/getAccountByStripeId": storeAccount("MAYAS FITNESS"),
    });

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      destinationAccountId: "acct_store",
      feeConfig: { percent: 2.9, fixed: 30 },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    // Both markers coexist: the per-invoice fee flag AND the descriptor stash.
    expect(createArg.subscription_data.metadata.bsFeeMode).toBe("per_invoice");
    expect(createArg.subscription_data.metadata.bsStatementDescriptor).toBe(
      "MAYAS FITNESS",
    );
    // Not a session/PI-level field in subscription mode.
    expect(createArg.payment_intent_data).toBeUndefined();
  });

  it("does not look up accounts or set a suffix for non-destination sales", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({});

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "payment",
      returnUrl: "https://app.test/return",
      defaultStatementDescriptorSuffix: "PLATFORM DEF",
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(
      createArg.payment_intent_data.statement_descriptor_suffix,
    ).toBeUndefined();
    const accountLookups = ctx.runQuery.mock.calls.filter((call: unknown[]) =>
      String((call[0] as Record<symbol, string>)[TO_REF]).includes(
        "getAccountByStripeId",
      ),
    );
    expect(accountLookups).toHaveLength(0);
  });

  it("callers cannot forge bsStatementDescriptor via metadata (reserved namespace stripped)", async () => {
    const stripe = makeStripe();
    stripe.checkout.sessions.create.mockResolvedValue(sessionResponse());
    const ctx = routedCtx({});

    await createCheckoutSession(asStripe(stripe), makeComponent(), ctx, {
      userId: "buyer_1",
      stripePriceId: "price_1",
      mode: "subscription",
      returnUrl: "https://app.test/return",
      metadata: { bsStatementDescriptor: "FORGED" },
    });

    const createArg = stripe.checkout.sessions.create.mock.calls[0][0];
    expect(
      createArg.subscription_data.metadata.bsStatementDescriptor,
    ).toBeUndefined();
  });
});
