// @vitest-environment edge-runtime
/**
 * Tests for the core Account methods. These functions span three boundaries:
 * the Stripe V2 Accounts SDK (`stripe.v2.core.accounts.*` plus `accountLinks`),
 * the component query/mutation layer (resolved via `componentRef`), and the
 * `deriveAccountStatus` helper. The headline targets are the multi-step
 * orchestrators — `createAccount`, `createAccountWithOnboarding` (with its
 * rollback path), `getOrCreateAccount`, `closeAccount` (DB-vs-Stripe fallback),
 * `listStripeAccounts`, and `syncAllAccounts` (SDK auto-pagination via
 * `for await` + per-record error accumulation). We assert the exact params handed to each boundary, the
 * shapes returned, every branch, and the error/rollback paths.
 *
 * Most of the suite mocks `ctx`/the component entirely (fast, boundary-focused
 * unit tests). The `addRecipientConfiguration` idempotency test (BTS-78) is
 * the exception: it runs against a REAL `convex-test` store — see the
 * "addRecipientConfiguration (real convex-test store)" describe block below —
 * because a genuine double-write/overwrite conflict needs a real row to
 * conflict against; a fully-mocked `runMutation` can never fail that way.
 */
import { describe, expect, it, vi } from "vitest";

import type { Component, RunCtx } from "../helpers.js";
import { components, initConvexTest } from "../setup.test.js";
import schema from "../../component/schema.js";
import {
  DEFAULT_ACCOUNT_CONFIGURATION,
  DEFAULT_ACCOUNT_DEFAULTS,
  DEFAULT_CUSTOMER_CONFIGURATION,
  addCustomerConfiguration,
  addRecipientConfiguration,
  ensureCustomerAccount,
  closeAccount,
  createAccount,
  createAccountWithOnboarding,
  getAccount,
  getAccountByOrgId,
  getAccountByStripeId,
  getAccountByUserId,
  getAccountOnboardingStatus,
  getOrCreateAccount,
  getV2Account,
  listStripeAccounts,
  restartAccountOnboarding,
  setAccountStatementDescriptor,
  syncAllAccounts,
  updateAccount,
  updateV2Account,
  upsertAccount,
} from "./accounts.js";

const TO_REF = Symbol.for("toReferencePath");

/** A fake component whose nested refs carry the Symbol the resolver looks up. */
function makeComponent(): Component {
  const ref = (path: string) => ({ [TO_REF]: `betterStripe/${path}` });
  return {
    core: {
      queries: {
        getAccount: ref("core/queries/getAccount"),
        getAccountByStripeId: ref("core/queries/getAccountByStripeId"),
        getAccountByUserId: ref("core/queries/getAccountByUserId"),
        getAccountByOrgId: ref("core/queries/getAccountByOrgId"),
        getAccountOnboardingStatus: ref(
          "core/queries/getAccountOnboardingStatus",
        ),
      },
      mutations: {
        upsertAccount: ref("core/mutations/upsertAccount"),
        deleteAccountByStripeId: ref("core/mutations/deleteAccountByStripeId"),
        setStatementDescriptor: ref("core/mutations/setStatementDescriptor"),
      },
    },
  } as unknown as Component;
}

/** The reference object the resolver returns for a given path. */
function refFor(path: string) {
  return { [TO_REF]: `betterStripe/${path}` };
}

/** Build a mock Stripe instance exposing only the slice these helpers touch. */
function makeStripe() {
  return {
    v2: {
      core: {
        accounts: {
          create: vi.fn(),
          update: vi.fn(),
          retrieve: vi.fn(),
          list: vi.fn(),
          close: vi.fn(),
        },
      },
    },
    accountLinks: { create: vi.fn() },
  };
}

type MockStripe = ReturnType<typeof makeStripe>;
const asStripe = (s: MockStripe) =>
  s as unknown as Parameters<typeof createAccount>[0];

/**
 * Real V2 list responses (`stripe.v2.core.accounts.list(...)`) are an
 * `AsyncIterableIterator` that follows `next_page_url` internally — they do
 * NOT resolve to a plain `{ data, has_more }` object a caller can inspect.
 * This mirrors that shape so `for await` consumes it the same way it would
 * consume the real SDK response.
 */
function asyncIterable<T>(items: T[]) {
  return {
    async *[Symbol.asyncIterator]() {
      for (const item of items) yield item;
    },
  };
}

// =============================================================================
// Real convex-test store helpers (BTS-78) — used only by the
// "addRecipientConfiguration (real convex-test store)" suite below. Registers
// the component as an actual CHILD COMPONENT named "betterStripe" (mirroring
// how an installing app wires it up in production, via
// `app.use(betterStripe, ...)`), so `components.betterStripe.*` — the same
// typed proxy `setup.test.ts` exports — resolves to REAL function references
// that `t.query`/`t.mutation` execute against a genuine in-memory backend,
// rather than a `vi.fn()`. (A flat `convexTest(componentSchema, componentModules)`
// with the component's own generated `api` doesn't work here: `componentRef`
// resolves via the childComponent `toReferencePath` symbol that only
// `componentsGeneric()`-based refs like `components.betterStripe.*` carry.)
// =============================================================================
const componentModules = import.meta.glob(
  "../../component/**/*.{ts,js,tsx,jsx}",
);

/** A real convex-test instance with the component registered as child "betterStripe". */
function makeRealConvexTest() {
  const t = initConvexTest();
  t.registerComponent("betterStripe", schema, componentModules);
  return t;
}

/** A `RunCtx` backed by a real convex-test instance. */
function makeRealCtx(t: ReturnType<typeof makeRealConvexTest>): RunCtx {
  return {
    runQuery: (ref: any, args: any) => t.query(ref, args),
    runMutation: (ref: any, args: any) => t.mutation(ref, args),
  } as unknown as RunCtx;
}

const realComponent = components.betterStripe as unknown as Component;

/**
 * `runInComponent` (read/write the mock backend scoped to a registered child
 * component) isn't part of convex-test's public `.d.ts` surface, only its
 * runtime API — narrow the cast to just this one method instead of reaching
 * for `any` on the whole test handle.
 */
type RunInComponent = (
  componentPath: string,
  handler: (ctx: {
    db: {
      query: (table: "accounts") => {
        collect: () => Promise<
          Array<{ stripeAccountId: string; userId: string }>
        >;
      };
    };
  }) => Promise<Array<{ stripeAccountId: string; userId: string }>>,
) => Promise<Array<{ stripeAccountId: string; userId: string }>>;

describe("createAccount", () => {
  it("creates the V2 account, upserts it, and returns the stored internal id", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_1" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const runQuery = vi.fn().mockResolvedValue({ _id: "internal_1" });
    const ctx = { runMutation, runQuery } as unknown as RunCtx;

    const result = await createAccount(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_1",
      email: "a@b.com",
      name: "Acme",
      country: "US",
    });

    expect(result).toEqual({
      accountId: "internal_1",
      stripeAccountId: "acct_1",
    });

    // Stripe create params: contact_email + metadata (userId injected), identity from country
    expect(stripe.v2.core.accounts.create).toHaveBeenCalledWith({
      contact_email: "a@b.com",
      metadata: { userId: "user_1" },
      identity: { country: "US" },
    });

    // Upsert mutation carries the derived metadata and pending defaults
    expect(runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/upsertAccount"),
      {
        stripeAccountId: "acct_1",
        userId: "user_1",
        orgId: undefined,
        email: "a@b.com",
        name: "Acme",
        country: "US",
        appliedConfigurations: [],
        onboardingStatus: "pending",
        metadata: { userId: "user_1" },
      },
    );

    // Read-back query keyed by the new Stripe id
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByStripeId"),
      { stripeAccountId: "acct_1" },
    );
  });

  it("merges orgId and caller metadata, and omits identity when no country", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_2" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const runQuery = vi.fn().mockResolvedValue({ _id: "internal_2" });
    const ctx = { runMutation, runQuery } as unknown as RunCtx;

    await createAccount(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_2",
      orgId: "org_2",
      metadata: { plan: "pro" },
    });

    const createArg = stripe.v2.core.accounts.create.mock.calls[0][0];
    expect(createArg).toEqual({
      contact_email: undefined,
      metadata: { plan: "pro", userId: "user_2", orgId: "org_2" },
    });
    // no country → no identity key at all
    expect("identity" in createArg).toBe(false);
  });

  it("returns null accountId when the stored row cannot be read back", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_3" });
    const ctx = {
      runMutation: vi.fn().mockResolvedValue(undefined),
      runQuery: vi.fn().mockResolvedValue(null),
    } as unknown as RunCtx;

    const result = await createAccount(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_3",
    });

    expect(result).toEqual({ accountId: null, stripeAccountId: "acct_3" });
  });

  it("throws when ctx has no runMutation", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_4" });
    const ctx = { runQuery: vi.fn() } as unknown as RunCtx;

    await expect(
      createAccount(asStripe(stripe), makeComponent(), ctx, { userId: "u" }),
    ).rejects.toThrow(/requires a Convex ctx with runMutation/);
  });
});

describe("createAccountWithOnboarding", () => {
  function happyCtx() {
    return {
      runMutation: vi.fn().mockResolvedValue(undefined),
      runQuery: vi.fn().mockResolvedValue({ _id: "internal_x" }),
    } as unknown as RunCtx & { runMutation: ReturnType<typeof vi.fn> };
  }

  it("applies default configuration, re-fetches applied configs, and returns the onboarding url", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_ob" });
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["merchant"],
    });
    stripe.accountLinks.create.mockResolvedValue({ url: "https://onboard" });
    const ctx = happyCtx();

    const result = await createAccountWithOnboarding(
      asStripe(stripe),
      makeComponent(),
      ctx,
      {
        userId: "user_ob",
        country: "US",
        refreshUrl: "https://refresh",
        returnUrl: "https://return",
      },
    );

    expect(result).toEqual({
      stripeAccountId: "acct_ob",
      onboardingUrl: "https://onboard",
    });

    // defaults applied + dashboard defaults to "express"
    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_ob", {
      configuration: DEFAULT_ACCOUNT_CONFIGURATION,
      dashboard: "express",
      defaults: DEFAULT_ACCOUNT_DEFAULTS,
    });

    // second upsert records the applied configs + in_progress status
    const secondUpsert = (
      ctx.runMutation as ReturnType<typeof vi.fn>
    ).mock.calls.find(
      (c) =>
        c[1].onboardingStatus === "in_progress" &&
        c[1].stripeAccountId === "acct_ob",
    );
    expect(secondUpsert?.[1]).toEqual({
      stripeAccountId: "acct_ob",
      userId: "user_ob",
      appliedConfigurations: ["merchant"],
      onboardingStatus: "in_progress",
    });

    // account link built with the right type + urls
    expect(stripe.accountLinks.create).toHaveBeenCalledWith({
      account: "acct_ob",
      refresh_url: "https://refresh",
      return_url: "https://return",
      type: "account_onboarding",
    });
  });

  it("honours caller-provided configuration, defaults, and dashboard", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_cfg" });
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({});
    stripe.accountLinks.create.mockResolvedValue({ url: "https://onboard" });
    const ctx = happyCtx();

    await createAccountWithOnboarding(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_cfg",
      country: "GB",
      refreshUrl: "https://refresh",
      returnUrl: "https://return",
      accountConfiguration: { recipient: {} },
      accountDefaults: { locales: ["en"] },
      dashboard: "none",
    });

    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_cfg", {
      configuration: { recipient: {} },
      dashboard: "none",
      defaults: { locales: ["en"] },
    });
  });

  it("defaults applied_configurations to [] when Stripe omits them", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_empty" });
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({}); // no applied_configurations
    stripe.accountLinks.create.mockResolvedValue({ url: "https://onboard" });
    const ctx = happyCtx();

    await createAccountWithOnboarding(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_empty",
      country: "US",
      refreshUrl: "https://refresh",
      returnUrl: "https://return",
    });

    const inProgress = (
      ctx.runMutation as ReturnType<typeof vi.fn>
    ).mock.calls.find((c) => c[1].onboardingStatus === "in_progress");
    expect(inProgress?.[1].appliedConfigurations).toEqual([]);
  });

  it("rolls back the Convex account and throws ACCOUNT_CREATE_FAILED when config update fails", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_fail" });
    stripe.v2.core.accounts.update.mockRejectedValue(new Error("config boom"));
    const ctx = happyCtx();

    await expect(
      createAccountWithOnboarding(asStripe(stripe), makeComponent(), ctx, {
        userId: "user_fail",
        country: "US",
        refreshUrl: "https://refresh",
        returnUrl: "https://return",
      }),
    ).rejects.toMatchObject({ data: { code: "ACCOUNT_CREATE_FAILED" } });

    // rollback deletes the half-created account
    expect(ctx.runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/deleteAccountByStripeId"),
      { stripeAccountId: "acct_fail" },
    );
    // never reached the account-link creation
    expect(stripe.accountLinks.create).not.toHaveBeenCalled();
  });

  it("still throws ACCOUNT_CREATE_FAILED even if the rollback delete also fails", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_fail2" });
    stripe.v2.core.accounts.update.mockRejectedValue(new Error("config boom"));
    const runMutation = vi
      .fn()
      .mockResolvedValueOnce(undefined) // initial upsert in createAccount
      .mockRejectedValueOnce(new Error("delete boom")); // rollback delete fails
    const ctx = {
      runMutation,
      runQuery: vi.fn().mockResolvedValue({ _id: "internal_x" }),
    } as unknown as RunCtx;

    await expect(
      createAccountWithOnboarding(asStripe(stripe), makeComponent(), ctx, {
        userId: "user_fail2",
        country: "US",
        refreshUrl: "https://refresh",
        returnUrl: "https://return",
      }),
    ).rejects.toMatchObject({ data: { code: "ACCOUNT_CREATE_FAILED" } });
  });
});

describe("getOrCreateAccount", () => {
  it("returns an existing account looked up by orgId without creating", async () => {
    const stripe = makeStripe();
    const runQuery = vi.fn().mockResolvedValue({
      _id: "internal_e",
      stripeAccountId: "acct_existing",
    });
    const ctx = { runQuery, runMutation: vi.fn() } as unknown as RunCtx;

    const result = await getOrCreateAccount(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { userId: "user_e", orgId: "org_e" },
    );

    expect(result).toEqual({
      accountId: "internal_e",
      stripeAccountId: "acct_existing",
      isNew: false,
    });
    // orgId branch → getAccountByOrgId
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByOrgId"),
      { orgId: "org_e" },
    );
    expect(stripe.v2.core.accounts.create).not.toHaveBeenCalled();
  });

  it("looks up by userId when no orgId is supplied", async () => {
    const stripe = makeStripe();
    const runQuery = vi.fn().mockResolvedValue({
      _id: "internal_u",
      stripeAccountId: "acct_u",
    });
    const ctx = { runQuery, runMutation: vi.fn() } as unknown as RunCtx;

    await getOrCreateAccount(asStripe(stripe), makeComponent(), ctx, {
      userId: "user_u",
    });

    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByUserId"),
      { userId: "user_u" },
    );
  });

  it("creates a new account and flags isNew when none exists", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_new" });
    // first query = existence check (null), second = read-back in createAccount
    const runQuery = vi
      .fn()
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce({ _id: "internal_new" });
    const ctx = {
      runQuery,
      runMutation: vi.fn().mockResolvedValue(undefined),
    } as unknown as RunCtx;

    const result = await getOrCreateAccount(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { userId: "user_new" },
    );

    expect(result).toEqual({
      accountId: "internal_new",
      stripeAccountId: "acct_new",
      isNew: true,
    });
  });
});

describe("read delegators", () => {
  it("getAccount queries getAccount with the opts", async () => {
    const runQuery = vi.fn().mockResolvedValue({ _id: "a" });
    const ctx = { runQuery } as unknown as RunCtx;
    const result = await getAccount(makeComponent(), ctx, { accountId: "a" });
    expect(result).toEqual({ _id: "a" });
    expect(runQuery).toHaveBeenCalledWith(refFor("core/queries/getAccount"), {
      accountId: "a",
    });
  });

  it("getAccountByUserId queries getAccountByUserId", async () => {
    const runQuery = vi.fn().mockResolvedValue(null);
    const ctx = { runQuery } as unknown as RunCtx;
    const result = await getAccountByUserId(makeComponent(), ctx, {
      userId: "u",
    });
    expect(result).toBeNull();
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByUserId"),
      { userId: "u" },
    );
  });

  it("getAccountByOrgId queries getAccountByOrgId", async () => {
    const runQuery = vi.fn().mockResolvedValue({ _id: "o" });
    const ctx = { runQuery } as unknown as RunCtx;
    await getAccountByOrgId(makeComponent(), ctx, { orgId: "o" });
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByOrgId"),
      { orgId: "o" },
    );
  });

  it("getAccountByStripeId queries getAccountByStripeId", async () => {
    const runQuery = vi.fn().mockResolvedValue({ _id: "s" });
    const ctx = { runQuery } as unknown as RunCtx;
    await getAccountByStripeId(makeComponent(), ctx, {
      stripeAccountId: "acct_x",
    });
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByStripeId"),
      { stripeAccountId: "acct_x" },
    );
  });

  it("getAccountOnboardingStatus queries getAccountOnboardingStatus", async () => {
    const runQuery = vi.fn().mockResolvedValue({ onboardingStatus: "pending" });
    const ctx = { runQuery } as unknown as RunCtx;
    const result = await getAccountOnboardingStatus(makeComponent(), ctx, {
      accountId: "a",
    });
    expect(result).toEqual({ onboardingStatus: "pending" });
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountOnboardingStatus"),
      { accountId: "a" },
    );
  });
});

describe("upsertAccount", () => {
  it("runs the upsert mutation with the raw opts and returns null", async () => {
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runMutation } as unknown as RunCtx;
    const opts = {
      stripeAccountId: "acct_up",
      userId: "user_up",
      onboardingStatus: "complete" as const,
    };

    const result = await upsertAccount(makeComponent(), ctx, opts);

    expect(result).toBeNull();
    expect(runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/upsertAccount"),
      opts,
    );
  });

  it("throws when ctx has no runMutation", async () => {
    const ctx = {} as unknown as RunCtx;
    await expect(
      upsertAccount(makeComponent(), ctx, {
        stripeAccountId: "acct_up",
        userId: "user_up",
      }),
    ).rejects.toThrow(/requires a Convex ctx with runMutation/);
  });
});

describe("updateAccount", () => {
  it("sends only the provided fields and returns success", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    const ctx = {} as RunCtx;

    const result = await updateAccount(asStripe(stripe), ctx, {
      stripeAccountId: "acct_u1",
      email: "new@b.com",
      metadata: { tier: "gold" },
    });

    expect(result).toEqual({ success: true });
    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_u1", {
      contact_email: "new@b.com",
      metadata: { tier: "gold" },
    });
  });

  it("sends an empty update when neither email nor metadata is provided", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    const ctx = {} as RunCtx;

    await updateAccount(asStripe(stripe), ctx, { stripeAccountId: "acct_u2" });

    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_u2", {});
  });
});

describe("getV2Account / updateV2Account", () => {
  it("getV2Account retrieves with the include array", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.retrieve.mockResolvedValue({ id: "acct_g" });
    const result = await getV2Account(asStripe(stripe), {} as RunCtx, {
      stripeAccountId: "acct_g",
      include: ["identity"] as never,
    });
    expect(result).toEqual({ id: "acct_g" });
    expect(stripe.v2.core.accounts.retrieve).toHaveBeenCalledWith("acct_g", {
      include: ["identity"],
    });
  });

  it("updateV2Account passes through the raw update params", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({ id: "acct_uv" });
    const updateParams = { contact_email: "x@y.com" } as never;
    const result = await updateV2Account(asStripe(stripe), {} as RunCtx, {
      stripeAccountId: "acct_uv",
      updateParams,
    });
    expect(result).toEqual({ id: "acct_uv" });
    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith(
      "acct_uv",
      updateParams,
    );
  });
});

describe("addRecipientConfiguration", () => {
  it("requests the recipient configuration and returns success", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["recipient"],
    });
    const runQuery = vi.fn().mockResolvedValue({ userId: "user_1" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    const result = await addRecipientConfiguration(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { stripeAccountId: "acct_r" },
    );
    expect(result).toEqual({
      success: true,
      appliedConfigurations: ["recipient"],
    });
    // V2 (API 2026-05-27.dahlia) requires the `capabilities` wrapper and an
    // explicit `requested: true`; the bare `recipient.stripe_balance` shape is
    // rejected with "Unknown field" (confirmed against the Stripe sandbox).
    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_r", {
      configuration: {
        recipient: {
          capabilities: {
            stripe_balance: { stripe_transfers: { requested: true } },
          },
        },
      },
    });
  });

  it("records the Stripe-reported applied configurations on the component account", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["recipient"],
    });
    const runQuery = vi.fn().mockResolvedValue({ userId: "user_1" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    await addRecipientConfiguration(asStripe(stripe), makeComponent(), ctx, {
      stripeAccountId: "acct_r",
    });

    // Read-back keyed by the Stripe id to recover the owning userId
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByStripeId"),
      { stripeAccountId: "acct_r" },
    );
    // Applied configs come from the re-fetched Stripe account (source of truth)
    expect(runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/upsertAccount"),
      {
        stripeAccountId: "acct_r",
        userId: "user_1",
        appliedConfigurations: ["recipient"],
      },
    );
  });

  it("throws ACCOUNT_NOT_FOUND and never touches Stripe when the account is not in the component DB", async () => {
    const stripe = makeStripe();
    const runQuery = vi.fn().mockResolvedValue(null);
    const runMutation = vi.fn();
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    await expect(
      addRecipientConfiguration(asStripe(stripe), makeComponent(), ctx, {
        stripeAccountId: "acct_missing",
      }),
    ).rejects.toMatchObject({ data: { code: "ACCOUNT_NOT_FOUND" } });

    expect(stripe.v2.core.accounts.update).not.toHaveBeenCalled();
    expect(runMutation).not.toHaveBeenCalled();
  });

  it("surfaces the error and never calls upsertAccount when update() succeeds but the re-fetch retrieve() throws (BTS-78)", async () => {
    // Partial-failure path: Stripe IS mutated (update() resolves), but the
    // re-fetch that reads back applied_configurations fails. The component
    // row must NOT be silently left stale — the error must propagate and
    // upsertAccount must never fire, so a caller can't mistake this for
    // success and no stale/absent row masks the real Stripe state.
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockRejectedValue(
      new Error("Stripe retrieve failed: connection reset"),
    );
    const runQuery = vi.fn().mockResolvedValue({ userId: "user_1" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    await expect(
      addRecipientConfiguration(asStripe(stripe), makeComponent(), ctx, {
        stripeAccountId: "acct_r",
      }),
    ).rejects.toThrow(/connection reset/);

    // Stripe was mutated...
    expect(stripe.v2.core.accounts.update).toHaveBeenCalledTimes(1);
    // ...but the component row was never touched — no silent stale write.
    expect(runMutation).not.toHaveBeenCalled();
  });
});

describe("addRecipientConfiguration (real convex-test store, BTS-78)", () => {
  it("persists exactly one account row reflecting the applied configuration — a real double-write/overwrite conflict would fail this", async () => {
    const t = makeRealConvexTest();
    const ctx = makeRealCtx(t);

    // Seed the pre-existing component row addRecipientConfiguration requires.
    await t.mutation(components.betterStripe.core.mutations.upsertAccount, {
      stripeAccountId: "acct_r",
      userId: "user_1",
      appliedConfigurations: [],
      onboardingStatus: "pending",
    });

    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["recipient"],
    });

    const result = await addRecipientConfiguration(
      asStripe(stripe),
      realComponent,
      ctx,
      { stripeAccountId: "acct_r" },
    );
    expect(result).toEqual({
      success: true,
      appliedConfigurations: ["recipient"],
    });

    // The REAL persisted row (not a mock return value) reflects the applied
    // configuration and preserves the owning userId.
    const stored = await t.query(
      components.betterStripe.core.queries.getAccountByStripeId,
      {
        stripeAccountId: "acct_r",
      },
    );
    expect(stored?.appliedConfigurations).toEqual(["recipient"]);
    expect(stored?.userId).toBe("user_1");

    // A subsequent full sync re-derives the same account from Stripe's list
    // endpoint and must PATCH the same row, not create a duplicate — the
    // double-sync regression this test guards against would show up here as
    // more than one row for the same stripeAccountId.
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([
        {
          id: "acct_r",
          configuration: { recipient: {} },
          metadata: { userId: "user_1" },
        },
      ]),
    );

    await syncAllAccounts(asStripe(stripe), realComponent, ctx);

    const allRows = await (
      t as unknown as { runInComponent: RunInComponent }
    ).runInComponent("betterStripe", async (dbCtx) =>
      dbCtx.db.query("accounts").collect(),
    );
    expect(allRows).toHaveLength(1);
    expect(allRows[0]?.stripeAccountId).toBe("acct_r");
    expect(allRows[0]?.userId).toBe("user_1");
  });
});

describe("listStripeAccounts", () => {
  it("collects every account the SDK's auto-pagination iterator yields", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([{ id: "acct_a" }, { id: "acct_b" }, { id: "acct_c" }]),
    );

    const result = await listStripeAccounts(asStripe(stripe), {} as RunCtx);

    expect(result.map((a) => a.id)).toEqual(["acct_a", "acct_b", "acct_c"]);
    expect(stripe.v2.core.accounts.list.mock.calls[0][0]).toEqual({
      limit: 100,
    });
  });

  it("honours an explicit limit", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(asyncIterable([]));

    const result = await listStripeAccounts(asStripe(stripe), {} as RunCtx, {
      limit: 5,
    });

    expect(result).toEqual([]);
    expect(stripe.v2.core.accounts.list).toHaveBeenCalledTimes(1);
    expect(stripe.v2.core.accounts.list.mock.calls[0][0]).toEqual({ limit: 5 });
  });

  it("returns accounts beyond a single page (BTS-109 regression)", async () => {
    // Real V2 list responses never populate `has_more` — a manual
    // has_more/starting_after loop reads it as `undefined` and silently
    // stops after page 1. The SDK's own async iterator (driven by
    // `next_page_url`, not exposed here) is what actually walks every page,
    // so draining a result set far larger than one page's `limit` proves
    // the fix relies on that iterator rather than a `has_more` flag.
    const stripe = makeStripe();
    const manyAccounts = Array.from({ length: 250 }, (_, i) => ({
      id: `acct_${i}`,
    }));
    stripe.v2.core.accounts.list.mockReturnValue(asyncIterable(manyAccounts));

    const result = await listStripeAccounts(asStripe(stripe), {} as RunCtx);

    expect(result).toHaveLength(250);
    expect(result.map((a) => a.id)).toEqual(manyAccounts.map((a) => a.id));
  });
});

describe("closeAccount / restartAccountOnboarding", () => {
  it("uses stored appliedConfigurations from the DB and deletes after Stripe close", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.close.mockResolvedValue({});
    const runQuery = vi.fn().mockResolvedValue({
      appliedConfigurations: ["merchant", "recipient"],
    });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    const result = await closeAccount(asStripe(stripe), makeComponent(), ctx, {
      stripeAccountId: "acct_close",
    });

    expect(result).toEqual({ closed: true });
    // never falls back to Stripe retrieve when DB has configs
    expect(stripe.v2.core.accounts.retrieve).not.toHaveBeenCalled();
    expect(stripe.v2.core.accounts.close).toHaveBeenCalledWith("acct_close", {
      applied_configurations: ["merchant", "recipient"],
    });
    expect(runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/deleteAccountByStripeId"),
      { stripeAccountId: "acct_close" },
    );
  });

  it("falls back to Stripe retrieve when the DB has no applied configs", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["merchant"],
    });
    stripe.v2.core.accounts.close.mockResolvedValue({});
    const ctx = {
      runQuery: vi.fn().mockResolvedValue(null), // no DB row
      runMutation: vi.fn().mockResolvedValue(undefined),
    } as unknown as RunCtx;

    await closeAccount(asStripe(stripe), makeComponent(), ctx, {
      stripeAccountId: "acct_fb",
    });

    expect(stripe.v2.core.accounts.retrieve).toHaveBeenCalledWith("acct_fb");
    expect(stripe.v2.core.accounts.close).toHaveBeenCalledWith("acct_fb", {
      applied_configurations: ["merchant"],
    });
  });

  it("closes with an empty config list when the Stripe retrieve fallback throws", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.retrieve.mockRejectedValue(
      new Error("no such account"),
    );
    stripe.v2.core.accounts.close.mockResolvedValue({});
    const ctx = {
      runQuery: vi.fn().mockResolvedValue(null),
      runMutation: vi.fn().mockResolvedValue(undefined),
    } as unknown as RunCtx;

    await closeAccount(asStripe(stripe), makeComponent(), ctx, {
      stripeAccountId: "acct_missing",
    });

    expect(stripe.v2.core.accounts.close).toHaveBeenCalledWith("acct_missing", {
      applied_configurations: [],
    });
  });

  it("does not delete from the DB if the Stripe close fails", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.close.mockRejectedValue(new Error("close boom"));
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = {
      runQuery: vi
        .fn()
        .mockResolvedValue({ appliedConfigurations: ["merchant"] }),
      runMutation,
    } as unknown as RunCtx;

    await expect(
      closeAccount(asStripe(stripe), makeComponent(), ctx, {
        stripeAccountId: "acct_err",
      }),
    ).rejects.toThrow(/close boom/);

    expect(runMutation).not.toHaveBeenCalled();
  });

  it("restartAccountOnboarding delegates to closeAccount", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.close.mockResolvedValue({});
    const ctx = {
      runQuery: vi.fn().mockResolvedValue({ appliedConfigurations: [] }),
      runMutation: vi.fn().mockResolvedValue(undefined),
    } as unknown as RunCtx;

    const result = await restartAccountOnboarding(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { stripeAccountId: "acct_restart" },
    );

    expect(result).toEqual({ closed: true });
    expect(stripe.v2.core.accounts.close).toHaveBeenCalledWith("acct_restart", {
      applied_configurations: [],
    });
  });
});

describe("syncAllAccounts", () => {
  it("maps a business V2 account into an upsert and counts it synced", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([
        {
          id: "acct_biz",
          contact_email: "biz@co.com",
          metadata: { userId: "u_biz", orgId: "o_biz" },
          identity: {
            country: "US",
            business_details: { registered_name: "Big Co" },
          },
          configuration: { merchant: { applied: true } },
          requirements: { entries: [] },
        },
      ]),
    );
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runMutation, runQuery: vi.fn() } as unknown as RunCtx;

    const result = await syncAllAccounts(
      asStripe(stripe),
      makeComponent(),
      ctx,
    );

    expect(result).toEqual({ synced: 1, errors: [], errorCount: 0 });

    const upsertArg = runMutation.mock.calls[0][1];
    expect(upsertArg).toMatchObject({
      stripeAccountId: "acct_biz",
      userId: "u_biz",
      orgId: "o_biz",
      email: "biz@co.com",
      name: "Big Co",
      country: "US",
      onboardingStatus: "complete",
      missingRequirements: [],
      metadata: { userId: "u_biz", orgId: "o_biz" },
    });
    // list called with limit 20
    expect(stripe.v2.core.accounts.list.mock.calls[0][0]).toEqual({
      limit: 20,
    });
  });

  it("derives an individual name, falls back to contact email, and accepts snake_case ids", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([
        {
          id: "acct_ind",
          metadata: { user_id: "u_snake", org_id: "o_snake" },
          identity: {
            country: "CA",
            individual: {
              given_name: "Jane",
              surname: "Doe",
              email: "jane@x.com",
            },
          },
        },
      ]),
    );
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runMutation, runQuery: vi.fn() } as unknown as RunCtx;

    await syncAllAccounts(asStripe(stripe), makeComponent(), ctx);

    const upsertArg = runMutation.mock.calls[0][1];
    expect(upsertArg).toMatchObject({
      userId: "u_snake",
      orgId: "o_snake",
      email: "jane@x.com", // individual.email fallback (no contact_email)
      name: "Jane Doe", // given_name + surname
      country: "CA",
    });
  });

  it("falls back to the account id as userId when metadata has none", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([{ id: "acct_noid" }]),
    );
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runMutation, runQuery: vi.fn() } as unknown as RunCtx;

    await syncAllAccounts(asStripe(stripe), makeComponent(), ctx);

    const upsertArg = runMutation.mock.calls[0][1];
    expect(upsertArg.userId).toBe("acct_noid");
    expect(upsertArg.orgId).toBeUndefined();
    expect(upsertArg.email).toBeUndefined();
    expect(upsertArg.name).toBeUndefined();
  });

  it("accumulates a per-account error instead of aborting the sync", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([
        { id: "acct_ok", metadata: { userId: "ok" } },
        { id: "acct_bad", metadata: { userId: "bad" } },
      ]),
    );
    const runMutation = vi
      .fn()
      .mockResolvedValueOnce(undefined) // acct_ok
      .mockRejectedValueOnce(new Error("db down")); // acct_bad
    const ctx = { runMutation, runQuery: vi.fn() } as unknown as RunCtx;

    const result = await syncAllAccounts(
      asStripe(stripe),
      makeComponent(),
      ctx,
    );

    expect(result.synced).toBe(1);
    expect(result.errorCount).toBe(1);
    expect(result.errors[0]).toContain("acct_bad");
    expect(result.errors[0]).toContain("db down");
  });

  it("stringifies a non-Error thrown value as 'Unknown error'", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([{ id: "acct_weird", metadata: { userId: "u" } }]),
    );
    const runMutation = vi.fn().mockRejectedValueOnce("not-an-error-object");
    const ctx = { runMutation, runQuery: vi.fn() } as unknown as RunCtx;

    const result = await syncAllAccounts(
      asStripe(stripe),
      makeComponent(),
      ctx,
    );

    expect(result.errorCount).toBe(1);
    expect(result.errors[0]).toBe("Account acct_weird: Unknown error");
  });

  it("leaves name undefined for an individual with no given_name or surname", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(
      asyncIterable([
        {
          id: "acct_blank",
          metadata: { userId: "u" },
          identity: { individual: { email: "only@email.com" } },
        },
      ]),
    );
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runMutation, runQuery: vi.fn() } as unknown as RunCtx;

    await syncAllAccounts(asStripe(stripe), makeComponent(), ctx);

    const upsertArg = runMutation.mock.calls[0][1];
    expect(upsertArg.name).toBeUndefined();
    expect(upsertArg.email).toBe("only@email.com");
  });

  it("handles an empty account list", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.list.mockReturnValue(asyncIterable([]));
    const ctx = {
      runMutation: vi.fn(),
      runQuery: vi.fn(),
    } as unknown as RunCtx;

    const result = await syncAllAccounts(
      asStripe(stripe),
      makeComponent(),
      ctx,
    );

    expect(result).toEqual({ synced: 0, errors: [], errorCount: 0 });
    expect(stripe.v2.core.accounts.list).toHaveBeenCalledTimes(1);
  });

  it("syncs accounts beyond a single page (BTS-109 regression)", async () => {
    // Same rationale as the listStripeAccounts regression test: real V2
    // list responses never populate `has_more`, so a manual pagination loop
    // silently stops after page 1 while reporting `errors: []` (looking
    // fully synced). Draining a result set far larger than one page's
    // `limit` proves syncAllAccounts relies on the SDK's async iterator
    // instead.
    const stripe = makeStripe();
    const manyAccounts = Array.from({ length: 150 }, (_, i) => ({
      id: `acct_${i}`,
      metadata: { userId: `user_${i}` },
    }));
    stripe.v2.core.accounts.list.mockReturnValue(asyncIterable(manyAccounts));
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runMutation, runQuery: vi.fn() } as unknown as RunCtx;

    const result = await syncAllAccounts(
      asStripe(stripe),
      makeComponent(),
      ctx,
    );

    expect(result).toEqual({ synced: 150, errors: [], errorCount: 0 });
    expect(runMutation).toHaveBeenCalledTimes(150);
  });
});

describe("addCustomerConfiguration", () => {
  it("DEFAULT_CUSTOMER_CONFIGURATION requests the customer configuration", () => {
    expect(DEFAULT_CUSTOMER_CONFIGURATION).toEqual({ customer: {} });
  });

  it("applies the customer configuration to the Stripe account", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["customer"],
    });
    const runQuery = vi.fn().mockResolvedValue({ userId: "user_1" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    await addCustomerConfiguration(asStripe(stripe), makeComponent(), ctx, {
      stripeAccountId: "acct_1",
    });

    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_1", {
      configuration: { customer: {} },
    });
  });

  it("never sends dashboard or defaults for a customer-only account", async () => {
    // A customer-only V2 account rejects `dashboard` and
    // `defaults.responsibilities` with `unsupported_field_for_configs`
    // (confirmed against the Stripe sandbox). Account config must be
    // configuration-aware: only recipient/merchant accounts set those.
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["customer"],
    });
    const ctx = {
      runQuery: vi.fn().mockResolvedValue({ userId: "user_1" }),
      runMutation: vi.fn().mockResolvedValue(undefined),
    } as unknown as RunCtx;

    await addCustomerConfiguration(asStripe(stripe), makeComponent(), ctx, {
      stripeAccountId: "acct_1",
    });

    const [, payload] = stripe.v2.core.accounts.update.mock.calls[0];
    expect(payload).not.toHaveProperty("dashboard");
    expect(payload).not.toHaveProperty("defaults");
    // ...and not nested inside `configuration` either.
    expect(payload.configuration).not.toHaveProperty("dashboard");
    expect(payload.configuration).not.toHaveProperty("defaults");
  });

  it("records the Stripe-reported applied configurations on the component account", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["customer"],
    });
    const runQuery = vi.fn().mockResolvedValue({ userId: "user_1" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    await addCustomerConfiguration(asStripe(stripe), makeComponent(), ctx, {
      stripeAccountId: "acct_1",
    });

    // Read-back keyed by the Stripe id to recover the owning userId
    expect(runQuery).toHaveBeenCalledWith(
      refFor("core/queries/getAccountByStripeId"),
      { stripeAccountId: "acct_1" },
    );
    // Applied configs come from the re-fetched Stripe account (source of truth)
    expect(runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/upsertAccount"),
      {
        stripeAccountId: "acct_1",
        userId: "user_1",
        appliedConfigurations: ["customer"],
      },
    );
  });

  it("returns success with the applied configurations", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["customer", "merchant"],
    });
    const runQuery = vi.fn().mockResolvedValue({ userId: "user_1" });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    const result = await addCustomerConfiguration(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { stripeAccountId: "acct_1" },
    );

    expect(result).toEqual({
      success: true,
      appliedConfigurations: ["customer", "merchant"],
    });
  });

  it("throws ACCOUNT_NOT_FOUND and never touches Stripe when the account is not in the component DB", async () => {
    const stripe = makeStripe();
    const runQuery = vi.fn().mockResolvedValue(null);
    const runMutation = vi.fn();
    const ctx = { runQuery, runMutation } as unknown as RunCtx;

    await expect(
      addCustomerConfiguration(asStripe(stripe), makeComponent(), ctx, {
        stripeAccountId: "acct_missing",
      }),
    ).rejects.toMatchObject({ data: { code: "ACCOUNT_NOT_FOUND" } });

    expect(stripe.v2.core.accounts.update).not.toHaveBeenCalled();
    expect(runMutation).not.toHaveBeenCalled();
  });
});

describe("ensureCustomerAccount (BTS-18)", () => {
  /** Build a ctx whose runQuery routes by component ref path. */
  function routedCtx(routes: Record<string, unknown>) {
    const runQuery = vi.fn(async (ref: Record<symbol, string>) => {
      const path = ref[TO_REF].replace(/^betterStripe\//, "");
      return routes[path] ?? null;
    });
    const runMutation = vi.fn().mockResolvedValue(undefined);
    return { runQuery, runMutation } as unknown as RunCtx & {
      runQuery: ReturnType<typeof vi.fn>;
      runMutation: ReturnType<typeof vi.fn>;
    };
  }

  it("provisions a new buyer with the customer configuration", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.create.mockResolvedValue({ id: "acct_new" });
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["customer"],
    });
    const ctx = routedCtx({
      "core/queries/getAccountByUserId": null, // no existing account
      "core/queries/getAccountByStripeId": {
        _id: "doc1",
        stripeAccountId: "acct_new",
        userId: "u1",
        appliedConfigurations: [],
      },
    });

    const result = await ensureCustomerAccount(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { userId: "u1", email: "buyer@test.com" },
    );

    expect(stripe.v2.core.accounts.create).toHaveBeenCalled();
    // customer configuration applied
    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_new", {
      configuration: { customer: {} },
    });
    expect(result.stripeAccountId).toBe("acct_new");
    expect(result.isNew).toBe(true);
    expect(result.appliedConfigurations).toContain("customer");
  });

  it("adds the customer configuration to an existing account that lacks it", async () => {
    const stripe = makeStripe();
    stripe.v2.core.accounts.update.mockResolvedValue({});
    stripe.v2.core.accounts.retrieve.mockResolvedValue({
      applied_configurations: ["customer"],
    });
    const ctx = routedCtx({
      "core/queries/getAccountByUserId": {
        _id: "doc1",
        stripeAccountId: "acct_x",
      },
      "core/queries/getAccountByStripeId": {
        _id: "doc1",
        stripeAccountId: "acct_x",
        userId: "u1",
        appliedConfigurations: [],
      },
    });

    const result = await ensureCustomerAccount(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { userId: "u1" },
    );

    expect(stripe.v2.core.accounts.create).not.toHaveBeenCalled();
    expect(stripe.v2.core.accounts.update).toHaveBeenCalledWith("acct_x", {
      configuration: { customer: {} },
    });
    expect(result.isNew).toBe(false);
  });

  it("is idempotent: does not re-provision an account that already has customer config", async () => {
    const stripe = makeStripe();
    const ctx = routedCtx({
      "core/queries/getAccountByUserId": {
        _id: "doc1",
        stripeAccountId: "acct_x",
      },
      "core/queries/getAccountByStripeId": {
        _id: "doc1",
        stripeAccountId: "acct_x",
        userId: "u1",
        appliedConfigurations: ["customer"],
      },
    });

    const result = await ensureCustomerAccount(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { userId: "u1" },
    );

    expect(stripe.v2.core.accounts.create).not.toHaveBeenCalled();
    expect(stripe.v2.core.accounts.update).not.toHaveBeenCalled();
    expect(result.appliedConfigurations).toEqual(["customer"]);
  });

  it("preserves other configs (customer + merchant) without re-provisioning", async () => {
    const stripe = makeStripe();
    const ctx = routedCtx({
      "core/queries/getAccountByUserId": {
        _id: "doc1",
        stripeAccountId: "acct_x",
      },
      "core/queries/getAccountByStripeId": {
        _id: "doc1",
        stripeAccountId: "acct_x",
        userId: "u1",
        appliedConfigurations: ["customer", "merchant"],
      },
    });

    const result = await ensureCustomerAccount(
      asStripe(stripe),
      makeComponent(),
      ctx,
      { userId: "u1" },
    );

    expect(stripe.v2.core.accounts.update).not.toHaveBeenCalled();
    expect(result.appliedConfigurations).toEqual(["customer", "merchant"]);
  });
});

describe("setAccountStatementDescriptor (BTS-32)", () => {
  it("validates, trims, and stores the per-store suffix on the account record", async () => {
    const runMutation = vi.fn().mockResolvedValue(null);
    const ctx = { runMutation } as unknown as RunCtx;

    const result = await setAccountStatementDescriptor(makeComponent(), ctx, {
      stripeAccountId: "acct_store",
      statementDescriptor: "  MAYAS FITNESS  ",
    });

    expect(result).toEqual({ success: true });
    expect(runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/setStatementDescriptor"),
      { stripeAccountId: "acct_store", statementDescriptor: "MAYAS FITNESS" },
    );
  });

  it("rejects an invalid suffix WITHOUT touching the component DB", async () => {
    const runMutation = vi.fn();
    const ctx = { runMutation } as unknown as RunCtx;

    await expect(
      setAccountStatementDescriptor(makeComponent(), ctx, {
        stripeAccountId: "acct_store",
        statementDescriptor: "BAD*NAME",
      }),
    ).rejects.toThrow(/character/i);
    expect(runMutation).not.toHaveBeenCalled();
  });

  it("clears the suffix when passed null", async () => {
    const runMutation = vi.fn().mockResolvedValue(null);
    const ctx = { runMutation } as unknown as RunCtx;

    const result = await setAccountStatementDescriptor(makeComponent(), ctx, {
      stripeAccountId: "acct_store",
      statementDescriptor: null,
    });

    expect(result).toEqual({ success: true });
    expect(runMutation).toHaveBeenCalledWith(
      refFor("core/mutations/setStatementDescriptor"),
      { stripeAccountId: "acct_store", statementDescriptor: null },
    );
  });
});
